export class IResponse {
    success: boolean | undefined;
    message: string | undefined;
    data: any;
}
