import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facultades',
  templateUrl: './facultades.component.html',
  styleUrls: ['./facultades.component.css']
})
export class FacultadesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
