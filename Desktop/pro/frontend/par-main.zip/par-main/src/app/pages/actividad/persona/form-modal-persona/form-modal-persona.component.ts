import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-modal-persona',
  templateUrl: './form-modal-persona.component.html',
  styleUrls: ['./form-modal-persona.component.css']
})
export class FormModalPersonaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
